function getMovies() {
	
	console.log("in js");



	let fetchPromise = fetch("http://localhost:3000/movies");



	fetchPromise

		.then((response) => {

			//console.log(response);

			if (response.status === 200)

				return response.json()

			else

				return Promise.reject(new Error('Could not fetch data'));

		})

		.then((movies) => {

			console.log(movies);

			let movielist = document.getElementsByTagName('ul')[0];

			let ulInnerHTML = "";

			let imageurl = "";

			movies.forEach((function (movie, index, initial_array) {
				ulInnerHTML += `<li>${movie.title} </br>  <img src=${movie.posterPath} class="" alt=${movie.title}/> </br> <button onclick="addFavourite(event,${movie.id})">Add to fav</button> </li> `;

			}))

			console.log(ulInnerHTML);

			movielist.getElementsByTagName('li')[0].innerHTML = ulInnerHTML;

			//movielist.getElementsByTagName('img')[0]=imageurl;

		})

		.catch((error) => {

			console.log(error);

		})

	return Promise;

}


function getFavourites() {
	
	let fetchPromise = fetch("http://localhost:3000/favourites");



	fetchPromise

		.then((response) => {

			//console.log(response);

			if (response.status === 200)

				return response.json()

			else

				return Promise.reject(new Error('Could not fetch data'));

		})

		.then((movies) => {

			console.log(movies);

			let movielist = document.getElementById('favouritesList');

			let ulInnerHTML = "";

			let imageurl = "";

			movies.forEach((function (movie, index, initial_array) {
				ulInnerHTML += `<li>${movie.title} </br>  <img src=${movie.posterPath} class="" alt=${movie.title}/> </br> <button onclick="addFavourite(event,${movie.id})">Add to fav</button> </li> `;

			}))

			console.log(ulInnerHTML);

			movielist.getElementsByTagName('li')[0].innerHTML = ulInnerHTML;

			//movielist.getElementsByTagName('img')[0]=imageurl;

		})

		.catch((error) => {

			console.log(error);

		})

	return Promise;

	console.log("in add to fav");

}



function addFavourite(e,i) {
	e.preventDefault();
 let url="http://localhost:3000/movies/"+i;
	let fetchPromise = fetch(url);

	fetchPromise

		.then((response) => {

			//console.log(response);

			if (response.status === 200)

				return response.json()

			else

				return Promise.reject(new Error('Could not fetch data'));

		})

		.then((movies) => {			
           console.log(movies);
		   fetch("http://localhost:3000/favourites",{
            method:'POST',
            headers :{
                'Content-Type':'application/json'
            },
            body:JSON.stringify(movies)
        })
        .then((response)=>{
            console.log(response);
            console.log('Record Added')
            getFavourites();
        })
        .catch((error=>{
            console.log(error);
        }))


		})

		.catch((error) => {

			console.log(error);

		})

	return Promise;



}



module.exports = {

	getMovies,

	getFavourites,

	addFavourite

};



	// You will get error - Uncaught ReferenceError: module is not defined

	// while running this script on browser which you shall ignore

	// as this is required for testing purposes and shall not hinder

	// it's normal execution